import React, { useState, ChangeEvent, FormEvent } from "react";

type FormFields = {
    name: string;
    email: string;
    subject: string;
    message: string;
};

type FormErrors = Partial<Record<keyof FormFields, string>>;

const initialFormValues: FormFields = {
    name: "",
    email: "",
    subject: "",
    message: "",
};

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const ContactUs: React.FC = () => {
    const [formData, setFormData] = useState<FormFields>(initialFormValues);
    const [errors, setErrors] = useState<FormErrors>({});
    const [submitting, setSubmitting] = useState<boolean>(false);
    const [submitted, setSubmitted] = useState<boolean>(false);

    const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {

        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));

        // Clear error on change
        if (errors[name as keyof FormFields]) {
            setErrors((prev) => ({
                ...prev,
                [name]: undefined,
            }));
        }
    };

    const validate = (): boolean => {
        const newErrors: FormErrors = {};
        if (!formData.name.trim()) newErrors.name = "Name is required.";
        if (!formData.email.trim()) newErrors.email = "Email is required.";
        else if (!emailRegex.test(formData.email))
            newErrors.email = "Please enter a valid email.";
        if (!formData.subject.trim()) newErrors.subject = "Subject is required.";
        if (!formData.message.trim()) newErrors.message = "Message is required.";

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        setSubmitted(false);

        if (!validate()) return;

        setSubmitting(true);

        // Fake async submission - replace with your API call
        setTimeout(() => {
            setSubmitting(false);
            setSubmitted(true);
            setFormData(initialFormValues);
        }, 2000);
    };

    return (
        <div className="max-w-4xl mx-auto p-6 sm:p-10">
            <h2 className="text-3xl font-bold text-center mb-10 text-gray-900 select-none">
                Contact Us
            </h2>

            <form
                onSubmit={handleSubmit}
                noValidate
                className="bg-white shadow-lg rounded-lg p-8 sm:p-10 mb-10"
                aria-label="Contact Form"
            >
                {/* Name */}
                <div className="mb-6">
                    <label
                        htmlFor="name"
                        className="block text-gray-700 font-semibold mb-2"
                    >
                        Name
                    </label>
                    <input
                        type="text"
                        id="name"
                        name="name"
                        placeholder="Your full name"
                        className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition ${errors.name
                            ? "border-red-500 focus:ring-red-500"
                            : "border-gray-300"
                            }`}
                        value={formData.name}
                        onChange={handleChange}
                        aria-invalid={Boolean(errors.name)}
                        aria-describedby="name-error"
                        disabled={submitting}
                    />
                    {errors.name && (
                        <p
                            id="name-error"
                            className="mt-1 text-red-600 text-sm select-none"
                            role="alert"
                        >
                            {errors.name}
                        </p>
                    )}
                </div>

                {/* Email */}
                <div className="mb-6">
                    <label
                        htmlFor="email"
                        className="block text-gray-700 font-semibold mb-2"
                    >
                        Email
                    </label>
                    <input
                        type="email"
                        id="email"
                        name="email"
                        placeholder="you@example.com"
                        className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition ${errors.email
                            ? "border-red-500 focus:ring-red-500"
                            : "border-gray-300"
                            }`}
                        value={formData.email}
                        onChange={handleChange}
                        aria-invalid={Boolean(errors.email)}
                        aria-describedby="email-error"
                        disabled={submitting}
                    />
                    {errors.email && (
                        <p
                            id="email-error"
                            className="mt-1 text-red-600 text-sm select-none"
                            role="alert"
                        >
                            {errors.email}
                        </p>
                    )}
                </div>

                {/* Subject */}
                <div className="mb-6">
                    <label
                        htmlFor="subject"
                        className="block text-gray-700 font-semibold mb-2"
                    >
                        Subject
                    </label>
                    <input
                        type="text"
                        id="subject"
                        name="subject"
                        placeholder="Subject"
                        className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition ${errors.subject
                            ? "border-red-500 focus:ring-red-500"
                            : "border-gray-300"
                            }`}
                        value={formData.subject}
                        onChange={handleChange}
                        aria-invalid={Boolean(errors.subject)}
                        aria-describedby="subject-error"
                        disabled={submitting}
                    />
                    {errors.subject && (
                        <p
                            id="subject-error"
                            className="mt-1 text-red-600 text-sm select-none"
                            role="alert"
                        >
                            {errors.subject}
                        </p>
                    )}
                </div>

                {/* Message */}
                <div className="mb-6">
                    <label
                        htmlFor="message"
                        className="block text-gray-700 font-semibold mb-2"
                    >
                        Message
                    </label>
                    <textarea
                        id="message"
                        name="message"
                        rows={5}
                        placeholder="Write your message here..."
                        className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 transition resize-y ${errors.message
                            ? "border-red-500 focus:ring-red-500"
                            : "border-gray-300"
                            }`}
                        value={formData.message}
                        onChange={handleChange}
                        aria-invalid={Boolean(errors.message)}
                        aria-describedby="message-error"
                        disabled={submitting}
                    ></textarea>
                    {errors.message && (
                        <p
                            id="message-error"
                            className="mt-1 text-red-600 text-sm select-none"
                            role="alert"
                        >
                            {errors.message}
                        </p>
                    )}
                </div>

                {/* Submit Button */}
                <button
                    type="submit"
                    disabled={submitting}
                    className={`w-full py-3 rounded-lg font-bold text-white shadow-md transition flex justify-center items-center gap-2 ${submitting
                        ? "bg-blue-600 cursor-not-allowed"
                        : "bg-blue-500 hover:bg-blue-600 focus:outline-none focus:ring-4 focus:ring-blue-300"
                        }`}
                    aria-live="polite"
                >
                    {submitting && <LoadingSpinner />}
                    {submitting ? "Sending..." : "Send"}
                </button>

                {/* Success message */}
                {submitted && (
                    <p
                        className="mt-4 text-green-600 font-semibold text-center select-none"
                        role="alert"
                    >
                        Thank you for contacting us! We will get back to you shortly.
                    </p>
                )}
            </form>

            {/* Google Map */}
            <div className="rounded-lg overflow-hidden shadow-lg">
                <iframe
                    title="Business Location"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3153.086688971202!2d-122.40159928468166!3d37.79361797975656!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80858064cc7a815d%3A0x26b081129d19f2a2!2sSalesforce%20Tower%2C%20415%20Mission%20St%2C%20San%20Francisco%2C%20CA%2094105%2C%20USA!5e0!3m2!1sen!2sus!4v1687123456789!5m2!1sen!2sus"
                    width="100%"
                    height="300"
                    loading="lazy"
                    className="border-0 w-full"
                    allowFullScreen
                    referrerPolicy="no-referrer-when-downgrade"
                />
            </div>

        </div>
    );
};

// Loading spinner component using Tailwind
const LoadingSpinner: React.FC = () => (
    <svg
        className="animate-spin h-5 w-5 text-white"
        xmlns="http://www.w3.org/2000/svg"
        fill="none"
        viewBox="0 0 24 24"
        aria-label="Loading"
        role="img"
    >
        <circle
            className="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="4"
        ></circle>
        <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
        ></path>
    </svg>
);

export default ContactUs;